import { Blog } from '../bloglist/model/bloghub';
import { BlogService } from './../blog.service';
import { Component } from '@angular/core';

@Component({
  selector: 'app-blogform',
  templateUrl: './blogform.component.html',
  styleUrls: ['./blogform.component.css']
})
export class BlogformComponent {
  categories=["technical","nature"];
  constructor(private service:BlogService){

  }
  insert(blog:Blog) 
  {

    console.log("inserting...");
    console.log("inserting..."+blog.title+" "+blog.category);
    this.service.addBlog(blog);
  }
}
