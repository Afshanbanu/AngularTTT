import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Student } from './student';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
private addStudent="http://localhost:8087/createStudent";
private getStudentsurl="http://localhost:8087/getAllStudents";
private getStudentByIdurl="http://localhost:8087/getStudentById";
private updateStudenturl="http://localhost:8087/updateStudent";
private deleteStudenturl="http://localhost:8087/deleteStudentById"
  constructor(private httpclient:HttpClient) { }

  createStudent(stud:Student):Observable<Object>
  {
    return this.httpclient.post(`${this.addStudent}`,stud);
  }
  getStudents()
  {
    return this.httpclient.get<Student[]>(`${this.getStudentsurl}`);
  }

  getStudentById(id: number): Observable<Student>{
    return this.httpclient.get<Student>(`${this.getStudentByIdurl}/${id}`);
  }

  updateStudent(id: number, student: Student): Observable<Object>{
    return this.httpclient.put(`${this.updateStudenturl}/${id}`, student);
  }

  deleteStudent(id: number): Observable<Object>{
    return this.httpclient.delete(`${this.deleteStudenturl}/${id}`);
  }
  
}
