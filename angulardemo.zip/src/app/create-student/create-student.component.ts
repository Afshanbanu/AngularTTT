import { Student } from './../student';
import { Component, OnInit } from '@angular/core';

import { StudentService } from '../student.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-student',
  templateUrl: './create-student.component.html',
  styleUrls: ['./create-student.component.css']
})
export class CreateStudentComponent implements OnInit {
  student:Student=new Student();
  students: Student[] = [];
  constructor(private studentservice:StudentService, private router: Router){}
  ngOnInit(): void {
    console.log("initiate....")
  }

  onSubmit()
  {
this.studentservice.createStudent(this.student).subscribe(data=>console.log(data))
  }
  geAll()
  {
    this.studentservice.getStudents().subscribe(data =>{  
      this.students =data;  
      })  
      
  }
  updateStudent(id:number)
  {
    console.log("inside update..."+id);
    this.router.navigate(['update-student', id]);
  }
  deleteStudent(id:number)
  {
    this.studentservice.deleteStudent(id).subscribe( data => {
      console.log(data);
      this.geAll();
    })
  }
  studentDetails(id:number)
  {
    this.student = new Student();
    this.studentservice.getStudentById(id).subscribe( data => {
      this.student = data;
    });
  }


}
