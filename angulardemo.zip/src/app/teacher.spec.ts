import { Teacher } from './teacher';

describe('Teacher', () => {
  it('should create an instance', () => {
    expect(new Teacher()).toBeTruthy();
  });
});
