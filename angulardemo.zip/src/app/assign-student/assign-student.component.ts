import { StudentService } from './../student.service';
import { Component, OnInit } from '@angular/core';
import { TeacherService } from '../teacher.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Student } from '../student';
import { Teacher } from '../teacher';

@Component({
  selector: 'app-assign-student',
  templateUrl: './assign-student.component.html',
  styleUrls: ['./assign-student.component.css']
})
export class AssignStudentComponent implements OnInit {
  sid!: number;
  tid!: number;
  student:Student=new Student();
  teacher:Teacher=new Teacher();
  constructor(private teacherservice:TeacherService, private studentService:StudentService, private route: ActivatedRoute,
    private router: Router){}
  ngOnInit(): void {
    this.tid = this.route.snapshot.params['id'];

    this.studentService.getStudentById(this.sid).subscribe(data => {
      this.student = data;
    }, error => console.log(error));
  }
  onSubmit()
  {
    console.log("inside update..."+this.sid);
    this.teacherservice.assignStudenttoTeacher(this.sid,this.tid, this.student).subscribe(data =>{  
      console.log(data)}); 
  }
}
