import { Teacher } from "./teacher";

export class Student {
    id!: number;
	name!: string;
	pno!: String;
}
