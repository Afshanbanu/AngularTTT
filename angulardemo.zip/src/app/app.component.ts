import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title="Angular Demo";
  obj = {ename:"john", "marks":89 };
  arr=[23,45,90];
  no=20;
  course='Angular';
  image=".../assets/anudip.png";
  fun(){alert('button clicked');}
  url="https://aln.anudip.org/login/index.php";
  nocol=3;
  isSpecial:boolean=false;
  currentClasses = {"city"    : true, "big"   : true};
  brightRed = {"color"  : "red", "font-size"  : "30pt"};
  Counter = 5;
  value="";
  clearValue() {
    this.value="";
    console.log(this.value)
  }
  submit()
  {
    console.log(this.value)
  }

  employeeForm=new FormGroup({
Name: new FormControl(''),
desig: new FormControl(''),
Address:new FormGroup({
  country: new FormControl(''),
  city: new FormControl('')
})
  });
onSubmit()
{
  console.log(this.employeeForm.value);
}
contactForm = new FormGroup({
  firstname: new FormControl('Sachin',Validators.compose([Validators.required,Validators.minLength(10)])),
  lastname: new FormControl([Validators.required]),
  email: new FormControl(),
  gender: new FormControl(),
  isMarried: new FormControl(),
  country: new FormControl()
})


onClick() {
  console.log(this.contactForm.value);
}

onsubmittempform(contactForm) {
  console.log(contactForm.value);
}
}