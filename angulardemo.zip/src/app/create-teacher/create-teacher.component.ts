import { Component } from '@angular/core';
import { Teacher } from '../teacher';
import { TeacherService } from '../teacher.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-teacher',
  templateUrl: './create-teacher.component.html',
  styleUrls: ['./create-teacher.component.css']
})
export class CreateTeacherComponent {
  teacher:Teacher=new Teacher();
  teachers: Teacher[] = [];
  constructor(private teacherservice:TeacherService, private router: Router){}
  ngOnInit(): void {
    console.log("initiate....")
  }

  onSubmit()
  {
this.teacherservice.createTeacher(this.teacher).subscribe(data=>console.log(data))
  }
  geAll()
  {
    this.teacherservice.getTeachers().subscribe(data =>{  
      this.teachers =data;  
      })  
      
  }
  assignStudent(tid:number)
  {
    console.log("inside assignstudent..."+tid);
    this.router.navigate(['assign-student', tid]); 

  }
  

}
