import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CreateStudentComponent } from './create-student/create-student.component';
import { HttpClientModule } from '@angular/common/http';
import { UpdateStudentComponent } from './update-student/update-student.component';
import { CreateTeacherComponent } from './create-teacher/create-teacher.component';
import { AssignStudentComponent } from './assign-student/assign-student.component';
@NgModule({
  declarations: [
    AppComponent,
    CreateStudentComponent,
    UpdateStudentComponent,
    CreateTeacherComponent, AssignStudentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule, ReactiveFormsModule, HttpClientModule, RouterModule,
  ],
  exports:[CreateStudentComponent, UpdateStudentComponent, CreateTeacherComponent,AssignStudentComponent ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
