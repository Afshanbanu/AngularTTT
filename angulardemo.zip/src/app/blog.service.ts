import { Injectable } from '@angular/core';
import { Blog } from './bloglist/model/bloghub';
import { blogs } from './bloglist/model/bloglist';

@Injectable({
  providedIn: 'root'
})
export class BlogService {
blogs:Blog[]
  constructor() {this.blogs=blogs }
  addBlog(blog:Blog)
  {
    console.log(blog);
    let id=this.blogs.length;
    blog.id=id;
    this.blogs.unshift(blog);
    console.log(this.blogs);
    

  }
}
