export class Blog{
    constructor(public id:number,public title:string, public discr:string, public category:string){}
}