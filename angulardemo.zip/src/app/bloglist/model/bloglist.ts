import {Blog} from './bloghub';
export let blogs:Blog[]=[
new Blog(1,'spring', "technology for java web application", "technical")

]