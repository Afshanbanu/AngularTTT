import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BloglistComponent } from './bloglist/bloglist.component';
import { BlogformComponent } from './blogform/blogform.component';
import { FormsModule } from '@angular/forms';
import { CreateStudentComponent } from './create-student/create-student.component';
import { UpdateStudentComponent } from './update-student/update-student.component';
import { CreateTeacherComponent } from './create-teacher/create-teacher.component';
import { AssignStudentComponent } from './assign-student/assign-student.component';

const routes: Routes = [
  {path:'list',component:BloglistComponent},
  {path:'create',component:BlogformComponent},
  {path:'createstudent',component:CreateStudentComponent},
  {path:'update-student/:id',component:UpdateStudentComponent},
  {path:'createteacher',component:CreateTeacherComponent},
  {path:'assign-student/:id',component:AssignStudentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes), BrowserModule, FormsModule],
  exports: [RouterModule, BloglistComponent, BlogformComponent],
  declarations: [
    BloglistComponent,
    BlogformComponent
  ]
})
export class AppRoutingModule { }
