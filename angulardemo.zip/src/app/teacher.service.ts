import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Student } from './student';
import { Teacher } from './teacher';

@Injectable({
  providedIn: 'root'
})
export class TeacherService {

  private addTeacher="http://localhost:8087/createTeacher";
private getTeachersurl="http://localhost:8087/getAllTeachers";
private assignStudentToteacherurl="http://localhost:8087/assignStudentToTeacher";

  constructor(private httpclient:HttpClient) { }

  createTeacher(teacher:Teacher):Observable<Object>
  {
    return this.httpclient.post(`${this.addTeacher}`,teacher);
  }
  getTeachers()
  {
    return this.httpclient.get<Teacher[]>(`${this.getTeachersurl}`);
  }

  assignStudenttoTeacher(sid: number, tid:number, student:Student){
    student:Student;
    return this.httpclient.put(`${this.assignStudentToteacherurl}/${sid}/${tid}`,student);
  }

  
}
