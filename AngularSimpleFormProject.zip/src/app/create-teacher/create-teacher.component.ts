import { Component } from '@angular/core';
import { Teacher } from '../teacher';
import { TeacherService } from '../teacher.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-teacher',
  templateUrl: './create-teacher.component.html',
  styleUrls: ['./create-teacher.component.css']
})
export class CreateTeacherComponent {

  teacher:Teacher=new Teacher();
  teachers:Teacher[]=[];
  constructor(private teacherService:TeacherService, private router:Router){}
  onSubmit()
  {
this.teacherService.creatTeacher(this.teacher).subscribe(data=>console.log(data));
  }
  getTeachers()
  {
this.teacherService.getTeachers().subscribe(data=>{this.teachers=data});
  }
  assignStudent(tid:number)
  {
    console.log("inside update..."+tid);
        this.router.navigate(['assign-student',tid]);
      }
  }

