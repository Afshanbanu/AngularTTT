import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Teacher } from './teacher';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TeacherService {
private createTeacherUrl="http://localhost:8087/createTeacher";
private getteachersUrl="http://localhost:8087/getAllTeachers";
private assignStudentUrl="http://localhost:8087/assignStudentToTeacher"
  constructor(private httpclient:HttpClient) { }

creatTeacher(teacher:Teacher):Observable<Object>
{
return this.httpclient.post(`${this.createTeacherUrl}`,teacher);
}
getTeachers()
{
return this.httpclient.get<Teacher[]>(`${this.getteachersUrl}`);
}
assignStudentToTeacher(sid:number, tid:number)
{
  console.log("assign service...");
return this.httpclient.put(`${this.assignStudentUrl}/${sid}/${tid}`, "");
}

}
