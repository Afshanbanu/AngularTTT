import { Student } from "./student";

export class Teacher {
    id!: number;
	
	name!: string;
	course!: string;
	students!: Student[];
}
