import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UpdateStudentComponent } from './update-student/update-student.component';
import { CreateStudentComponent } from './create-student/create-student.component';
import { CreateTeacherComponent } from './create-teacher/create-teacher.component';
import { AssignStudentComponent } from './assign-student/assign-student.component';

const routes: Routes = [
  {path:'update-student/:id', component:UpdateStudentComponent},
  {path:'createstudent',component:CreateStudentComponent},
  {path:'createTeacher',component:CreateTeacherComponent},
  {path:'assign-student/:tid',component:AssignStudentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
