import { Injectable } from '@angular/core';
import { Student } from './student';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  private createstudenturl="http://localhost:8087/createStudent";
  private getStudentsurl="http://localhost:8087/getAllStudents";
  private deletestudent="http://localhost:8087/deleteStudentById";
  private getStudentByIdurl="http://localhost:8087/getStudentById";
private updatestudentUrl="http://localhost:8087/updateStudent";

  constructor(private httpclient:HttpClient) { }
createStudent(student:Student):Observable<Object>
{
  console.log("in service....");
 return this.httpclient.post(`${this.createstudenturl}`, student);
}
getStudents()
{
return this.httpclient.get<Student[]>(`${this.getStudentsurl}`);
}

deleteStudent(id:number):Observable<Object>
{
return this.httpclient.delete(`${this.deletestudent}/${id}`);
}
getStudentById(id: number): Observable<Student>{
      return this.httpclient.get<Student>(`${this.getStudentByIdurl}/${id}`);
    }
  updateStudent(id:number, student:Student):Observable<Object>
  {
return this.httpclient.put(`${this.updatestudentUrl}/${id}`, student);
  }
}
