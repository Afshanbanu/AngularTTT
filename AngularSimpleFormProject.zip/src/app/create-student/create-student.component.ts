import { Component } from '@angular/core';
import { StudentService } from '../student.service';
import { Student } from '../student';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-student',
  templateUrl: './create-student.component.html',
  styleUrls: ['./create-student.component.css']
})
export class CreateStudentComponent {
  student:Student=new Student();
  students: Student[] = [];
  
constructor(private service:StudentService, private router:Router)
{

}
onSubmit()
{
  console.log("inserting...");
  this.service.createStudent(this.student).subscribe(data=>console.log(data));
}
getstudents()
{
this.service.getStudents().subscribe(data =>{this.students=data});
}
deleteStudent(id:number)
  {
    this.service.deleteStudent(id).subscribe( data => {
      console.log(data);
      this.getstudents();
    })
  }

getStudentById(id:number)
{
  this.student = new Student();
this.service.getStudentById(id).subscribe(data=>this.student=data)
}

updateStudent(id:number)
  {
    console.log("inside update..."+id);
    this.router.navigate(['update-student', id]);
  }

}
