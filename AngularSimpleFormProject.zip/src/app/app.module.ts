import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { CreateStudentComponent } from './create-student/create-student.component'
import { FormsModule } from '@angular/forms';
import { UpdateStudentComponent } from './update-student/update-student.component';
import { RouterModule } from '@angular/router';
import { CreateTeacherComponent } from './create-teacher/create-teacher.component';
import { AssignStudentComponent } from './assign-student/assign-student.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateStudentComponent,
    UpdateStudentComponent,
    CreateTeacherComponent,
    AssignStudentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, HttpClientModule,FormsModule,RouterModule,
  ],
  providers: [],
  exports:[CreateStudentComponent, CreateTeacherComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
