import { TeacherService } from './../teacher.service';
import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-assign-student',
  templateUrl: './assign-student.component.html',
  styleUrls: ['./assign-student.component.css']
})
export class AssignStudentComponent implements OnInit {
student:Student=new Student();
  tid!: number;
  sid!: number;
  constructor(private teacherservice:TeacherService,  private route: ActivatedRoute,
        private router: Router)
  {}

ngOnInit(): void {
      this.tid = this.route.snapshot.params['tid'];
 }

  onSubmit()
  {
    console.log("assign submit..."+this.sid+" "+this.tid);
    this.teacherservice.assignStudentToTeacher(this.sid,this.tid).subscribe(data=>console.log(data));
  }
}
